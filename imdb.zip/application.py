from app import app

app.run()
